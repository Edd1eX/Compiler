//
// Created by 张瑞轩 on 2021/9/24.
//
#include<bits/stdc++.h>
using namespace std;
const string IDENFR = "IDENFR";
const string INTCON = "INTCON";
const string STRCON = "STRCON";
const string MAINTK = "MAINTK";
const string CONSTTK = "CONSTTK";
const string INTTK = "INTTK";
const string BREAKTK = "BREAKTK";
const string CONTINUETK = "CONTINUETK";
const string IFTK = "IFTK";
const string ELSETK = "ELSETK";
const string NOT = "NOT";
const string AND = "AND";
const string OR = "OR";
const string WHILETK = "WHILETK";
const string GETINTTK = "GETINTTK";
const string PRINTFTK = "PRINTFTK";
const string RETURNTK = "RETURNTK";
const string PLUS = "PLUS";
const string MINU = "MINU";
const string VOIDTK = "VOIDTK";
const string MULT = "MULT";
const string DIV = "DIV";
const string MOD = "MOD";
const string LSS = "LSS";
const string LEQ = "LEQ";
const string GRE = "GRE";
const string GEQ = "GEQ";
const string EQL = "EQL";
const string NEQ = "NEQ";
const string ASSIGN = "ASSIGN";
const string SEMICN = "SEMICN";
const string COMMA = "COMMA";
const string LPARENT = "LPARENT";
const string RPARENT = "RPARENT";
const string LBRACK = "LBRACK";
const string RBRACK = "RBRACK";
const string LBRACE = "LBRACE";
const string RBRACE = "RBRACE";