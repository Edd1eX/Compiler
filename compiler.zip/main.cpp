#include "lexicalAnalysis.h"

int main()
{
    analysis();
    return 0;
}